import axios from 'axios';

const API_KEY = 'ddeb50af696f4fd68a771f261609b983';
const NEWS_API_URL = 'https://newsapi.org/v2/top-headlines';

const fetchNews = async () => {
  try {
    const response = await axios.get(NEWS_API_URL, {
      params: {
        apiKey: API_KEY,
        country: 'ru', 
        category: 'general', 
      },
    });
    return response.data.articles;
  } catch (error) {
    throw new Error('Failed to fetch news');
  }
};

export default fetchNews;