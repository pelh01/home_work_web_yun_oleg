import React, { useState, useEffect } from 'react';
import News from './News';
import './NewsList.css';

const NewsList = () => {
  const [news, setNews] = useState([]);

  useEffect(() => {
    const getNews = async () => {
      try {
        const articles = await News();
        setNews(articles);
      } catch (error) {
        console.error(error.message);
      }
    };
    getNews();
  }, []);

  return (
    <div className="news-container">
      <h2 className="news-title">News</h2>
      <div className="news-grid">
        {news.map((article, index) => (
          <div className="news-item" key={index}>
            <a
              href={article.url}
              target="_blank"
              rel="noopener noreferrer"
              className="news-link"
            >
              <div className="news-image">
                {article.urlToImage && <img src={article.urlToImage} alt="Article" />}
              </div>
              <div className="news-info">
                <h3>{article.title}</h3>
                <p>{article.description}</p>
              </div>
            </a>
          </div>
        ))}
      </div>
    </div>
  );
};

export default NewsList;