
import React, { useState, useEffect } from 'react';
import axios from 'axios';

import './Weather.css';

const Weather = () => {

  const [city, setCity] = useState('');
  const [weatherData, setWeatherData] = useState(null);
  const [error, setError] = useState('');
  const [history, setHistory] = useState([]);

  useEffect(() => {
    const storedHistory = JSON.parse(localStorage.getItem('weatherHistory')) || [];
    setHistory(storedHistory);
  }, []);

  const addToHistory = (cityName) => {
    const updatedHistory = [...history];
    if (!updatedHistory.includes(cityName)) {
      updatedHistory.unshift(cityName);
      if (updatedHistory.length > 5) {
        updatedHistory.pop();
      }
      setHistory(updatedHistory);
      localStorage.setItem('weatherHistory', JSON.stringify(updatedHistory));
    }
  };

  const fetchWeather = async () => {
    try {
      const response = await axios.get(
        `https://api.openweathermap.org/data/2.5/weather?q=${city}&appid=908773ca37927523f250ee85111c08e5&units=metric`
      );
      setWeatherData(response.data);
      setError('');
      addToHistory(city);
    } catch (err) {
      setWeatherData(null);
      setError('City not found. Please try again.');
    }
  };

  const handleWeatherSearch = () => {
    if (city.trim() !== '') {
      fetchWeather();
    } else {
      setError('Please enter a city name.');
    }
  };

  const handleHistoryClick = (cityName) => {
    setCity(cityName);
    fetchWeather();
  };

  return (
    <div className="container">
      <h2>Weather App</h2>
      <input
        type="text"
        value={city}
        onChange={(e) => setCity(e.target.value)}
        placeholder="Enter city name"
      />
      <button onClick={handleWeatherSearch}>Get Weather</button>
      {error && <p className="error-message">{error}</p>}
      {weatherData && (
        <div className="weather-info">
          <h3>{weatherData.name}, {weatherData.sys.country}</h3>
          <p>Temperature: {weatherData.main.temp}°C</p>
          <p>Description: {weatherData.weather[0].description}</p>
        </div>
      )}
      {history.length > 0 && (
        <div className="history">
          <h3>Search History</h3>
          <ul>
            {history.map((item, index) => (
              <li key={index} onClick={() => handleHistoryClick(item)}>{item}</li>
            ))}
          </ul>
        </div>
      )}
    </div>
  );
};

export default Weather;