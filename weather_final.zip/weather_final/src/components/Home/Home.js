import React from 'react';
import "./Home.css"

const Home = () => {
  return (
    <div>
      <h1>Welcome to the Weather App</h1>

    </div>
  );
};

export default Home;