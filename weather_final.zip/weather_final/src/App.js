import React from 'react';
import { BrowserRouter as Router, Route, Routes, Link } from 'react-router-dom';
import Home from './components/Home/Home';
import Weather from './components/Weather/Weather';
import "./App.css"
import NewsList from './News/NewsList';

const App = () => {
  return (
    <Router>
      <div className="app-container"> 
        <nav className="header"> 
          <ul>
            <li>
              <Link to="/">Home</Link>
            </li>
            <li>
              <Link to="/weather">Weather</Link>
            </li>
            <li>
              <Link to="/news">News</Link>
            </li>
          </ul>
        </nav>

        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/weather" element={<Weather />} />
          <Route path="/news" element={<NewsList/>} />
        </Routes>
      </div>
    </Router>
  );
};

export default App;